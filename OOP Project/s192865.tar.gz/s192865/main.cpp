#include <iostream>
#include "markov_model.hpp"
#include <string>
#include <cstring>
#include <fstream>
#include <vector>


int main(int argc, char ** argv){

  std::vector <std::string>tf; 
  std::vector <std::string>tstf; 
  unsigned int order = 0;

  bool check = false;

  if(std::stoi(argv[1]) < 0){
    throw  std::invalid_argument("ORDER MUST BE GREATER THAN ZERO");
  }else{
    order = (unsigned int)std::stoi(argv[1]);
  }

  for (int i = 2; i < argc; ++i){
    if(!strcmp(argv[i], "---")){
      check = true;
      i++;
    }
    if(check){
      tstf.push_back(std::string(argv[i]));
    }else{
      tf.push_back(std::string(argv[i]));
    }
  }

  std::string trnamedata;
  std::string trdata;
  std::string tstdata;
  std::ifstream opf;
  std::ifstream opftst;
  Markov_model ptr;

  for(unsigned int j = 0; j < tstf.size(); j++){ 
    opf.open(tf[j], std::ios::in);
    if(opf.is_open()){
      std::getline(opf, trnamedata);
      std::getline(opf, trdata);
      try{
        markov_model(ptr,order, trdata);
        }catch(const std::exception e){
          std::cout << "Markov Model Failed" << std::endl;
        } 
      opf.close();
      }else{
        std::cout<< "File Doesn't Exist or File still close" << std::endl;
      }
    for(unsigned int k = 0; k < tstf.size(); k++){ 
      opftst.open(tstf[k], std::ios::in);
      if(opftst.is_open()){
        std:: getline(opftst, tstdata);
        try{
          std::cout << trnamedata << " : " << likelihood(ptr, tstdata) << std::endl;
          std::cout << tstf[k] << " attributed to " << tf[j] << std::endl;
          }catch(const std::exception& e){
            std::cout << "-" << std::endl;
            }
      opftst.close();
      }else{
        std::cout<< "File Doesn't Exist or File still close" << std::endl;
      }
    }
  }

    return 0;
}
